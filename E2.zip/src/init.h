//
// Created by miraddo on 6/2/2024.
// init.h

#ifndef INIT_H
#define INIT_H
void init();
#endif //INIT_H
