//
// Created by miraddo on 6/2/2024.
//

#ifndef STARTS_H
#define STARTS_H
void stars_init();
void stars_update();
void stars_draw();
#endif //STARTS_H
