//
// Created by miraddo on 6/2/2024.
//

#ifndef GLOBAL_VARIABLES_H
#define GLOBAL_VARIABLES_H
extern long frames;
extern long score;
#endif //GLOBAL_VARIABLES_H
