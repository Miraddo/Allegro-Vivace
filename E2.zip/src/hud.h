//
// Created by miraddo on 6/2/2024.
//

#ifndef HUD_H
#define HUD_H

void hud_init();
void hud_deinit();
void hud_update();
void hud_draw();

#endif //HUD_H
