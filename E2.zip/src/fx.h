//
// Created by miraddo on 6/2/2024.
//

#ifndef FX_H
#define FX_H

void fx_init();
void fx_add(bool spark, int x, int y);
void fx_update();
void fx_draw();

#endif //FX_H
