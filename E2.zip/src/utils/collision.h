//
// Created by miraddo on 6/2/2024.
//

#ifndef COLLISION_H
#define COLLISION_H
bool collide(int ax1, int ay1, int ax2, int ay2, int bx1, int by1, int bx2, int by2);
#endif //COLLISION_H
