//
// Created by miraddo on 6/2/2024.
//

#ifndef RANDOM_H
#define RANDOM_H

int between(int lo, int hi);
int between_f(float lo, float hi);

#endif //RANDOM_H
