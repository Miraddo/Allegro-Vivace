// helper.h
#ifndef HELPER_H    /* Include guard */
#define HELPER_H

void must_init(bool test, const char *description);  // function declaration

#endif /* HELPER_H */

