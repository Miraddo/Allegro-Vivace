#include "src/init.h"

int main()
{
    init();
    return 0;
}